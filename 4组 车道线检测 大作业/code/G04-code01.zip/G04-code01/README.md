安装环境：
conda env create -f environment.yml

conda activate carnd

运行代码：

图片：
```
python main.py INPUT_IMAGE OUTPUT_IMAGE_PATH


视频：
```
python main.py --video INPUT_VIDEO OUTPUT_VIDEO_PATH
```
