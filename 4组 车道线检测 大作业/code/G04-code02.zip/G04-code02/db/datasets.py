from db.tusimple import TUSIMPLE

datasets = {
    "TUSIMPLE": TUSIMPLE,
}
